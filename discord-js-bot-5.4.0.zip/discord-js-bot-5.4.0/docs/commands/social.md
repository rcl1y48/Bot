---
description: 2 commands
---

# 🧑 Social

| Command                 | Slash                | Description                |
| ----------------------- | -------------------- | -------------------------- |
| **!rep view \[member]** | **/reputation view** | view reputation for a user |
| **!rep give \[member]** | **/reputation give** | give reputation to a user  |
